/**
 * Cloudflare Workers Edge Native Serverless API Code
 * 
 * Interfacing with Cloudflare D1 Serverless SQL Database (SQLite)
 * Handles routing, CORS, security, and D1 database SELECT queries for Users.
 */

// Fallback interfaces for local React TypeScript compiler verification
interface D1Database {
  prepare(query: string): any;
}
interface ExecutionContext {
  waitUntil(promise: Promise<any>): void;
}

export interface Env {
  // D1 Database Binding configured in wrangler.toml
  DB: D1Database;
  JWT_SECRET?: string;
  APPWRITE_API_KEY?: string;
}

// Helper to parse base64 JWT payload safely at the Edge
function decodeJWT(token: string): any {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    let payloadBase64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    while (payloadBase64.length % 4) {
      payloadBase64 += '=';
    }
    const decoded = atob(payloadBase64);
    return JSON.parse(decoded);
  } catch (e) {
    return null;
  }
}

// Google ID token verification at the Edge with JWKs and standard Web Crypto APIs
async function verifyGoogleIdToken(idToken: string): Promise<any> {
  const parts = idToken.split('.');
  if (parts.length !== 3) {
    throw new Error('Invalid JWT format');
  }

  const header = decodeJWT(parts[0]);
  const payload = decodeJWT(parts[1]);
  if (!header || !payload) {
    throw new Error('Could not decode JWT parts');
  }

  // Check expiration (with a generous 60-second clock skew allowance)
  const nowSecs = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < nowSecs - 60) {
    throw new Error('Google ID token is expired');
  }

  // Verify Issuer
  const iss = payload.iss;
  if (iss !== 'https://accounts.google.com' && iss !== 'accounts.google.com') {
    throw new Error('Invalid token issuer');
  }

  // Try verifying using Google public certs
  try {
    const certsResponse = await fetch('https://www.googleapis.com/oauth2/v3/certs');
    if (!certsResponse.ok) {
      throw new Error(`Failed to fetch certs: ${certsResponse.statusText}`);
    }
    const certs: any = await certsResponse.json();
    const kid = header.kid;
    const jwk = certs.keys.find((key: any) => key.kid === kid);

    if (!jwk) {
      throw new Error(`JWK not found for kid: ${kid}`);
    }

    // Convert JWT signature part from base64url to Uint8Array
    let signatureStr = parts[2].replace(/-/g, '+').replace(/_/g, '/');
    while (signatureStr.length % 4) {
      signatureStr += '=';
    }
    const signatureBin = atob(signatureStr);
    const signatureArr = new Uint8Array(signatureBin.length);
    for (let i = 0; i < signatureBin.length; i++) {
      signatureArr[i] = signatureBin.charCodeAt(i);
    }

    // Convert header + payload string to Uint8Array
    const encoder = new TextEncoder();
    const dataArr = encoder.encode(`${parts[0]}.${parts[1]}`);

    // Import the public JWK and verify
    const publicKey = await crypto.subtle.importKey(
      'jwk',
      jwk,
      {
        name: 'RSASSA-PKCS1-v1_5',
        hash: { name: 'SHA-256' }
      },
      false,
      ['verify']
    );

    const isValid = await crypto.subtle.verify(
      'RSASSA-PKCS1-v1_5',
      publicKey,
      signatureArr,
      dataArr
    );

    if (!isValid) {
      throw new Error('Crypto verification failed: invalid signature');
    }

    return payload;
  } catch (error: any) {
    console.warn('[Worker Auth] Local JWK crypto verification failed. Attempting Google tokeninfo fallback...', error.message);
    
    // Fallback: Verify token directly using Google's tokeninfo API
    try {
      const tokenInfoUrl = `https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(idToken)}`;
      const tokenInfoResponse = await fetch(tokenInfoUrl);
      if (tokenInfoResponse.ok) {
        const info: any = await tokenInfoResponse.json();
        if (info.error_description) {
          throw new Error(info.error_description);
        }
        return info;
      } else {
        throw new Error(`Tokeninfo API failed with status ${tokenInfoResponse.status}`);
      }
    } catch (fallbackError: any) {
      console.error('[Worker Auth] Google tokeninfo fallback also failed:', fallbackError.message);
      throw new Error(`Google ID Token verification failed: ${error.message} && ${fallbackError.message}`);
    }
  }
}

// Generate secure edge JWT signed with HMAC-SHA256 standard
async function generateJWT(payload: any, secret: string): Promise<string> {
  const header = { alg: 'HS256', typ: 'JWT' };
  const base64UrlHeader = btoa(JSON.stringify(header)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const base64UrlPayload = btoa(JSON.stringify(payload)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  
  const tokenInput = `${base64UrlHeader}.${base64UrlPayload}`;
  
  const encoder = new TextEncoder();
  const keyData = encoder.encode(secret);
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  
  const signature = await crypto.subtle.sign(
    'HMAC',
    cryptoKey,
    encoder.encode(tokenInput)
  );
  
  const base64UrlSignature = btoa(String.fromCharCode(...new Uint8Array(signature)))
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
    
  return `${tokenInput}.${base64UrlSignature}`;
}

// Security verification helper to ensure only admins can access sensitive D1 endpoints
async function verifyAdmin(request: Request, env: Env): Promise<boolean> {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return false;
  }
  const token = authHeader.substring(7);
  const payload = decodeJWT(token);
  if (!payload) return false;

  const requesterId = payload.sub || payload.user_id || payload.uid;
  const requesterEmail = payload.email;

  // Primary administrator email bypass
  if (requesterEmail === 'nikhilrv8055@gmail.com') {
    return true;
  }

  if (!requesterId) return false;

  try {
    const dbUser: any = await env.DB.prepare(
      'SELECT role FROM users WHERE id = ?'
    ).bind(requesterId).first();

    return dbUser && dbUser.role === 'admin';
  } catch (e) {
    console.error('Error verifying admin status:', e);
    return false;
  }
}

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);
    const method = request.method;

    // --- Elegant CORS Headers for Cross-Origin API access ---
    const origin = request.headers.get('Origin') || '';
    const allowedOrigins = [
      'https://play.sorat.in',
      'https://sorat.live',
      'http://localhost:3000',
      'http://localhost:5173'
    ];
    let allowOrigin = '*';
    if (origin) {
      if (allowedOrigins.includes(origin) || origin.includes('sorat.in') || origin.includes('sorat.live') || origin.includes('run.app') || origin.includes('localhost')) {
        allowOrigin = origin;
      }
    }

    const corsHeaders = {
      'Access-Control-Allow-Origin': allowOrigin,
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400',
    };

    // Handle CORS preflight options request
    if (method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    try {
      // Dynamic Matcher for `/api/users/:id` routes
      const userMatch = url.pathname.match(/^\/api\/users\/([^/]+)$/);
      const proofMatch = url.pathname.match(/^\/api\/payment-proofs\/([^/]+)$/);

      // Route: GET /api/game-state - Universal mathematical time anchored round status
      if (url.pathname === '/api/game-state' && method === 'GET') {
        const currentTimestamp = Math.floor(Date.now() / 1000);
        const currentSecondInCycle = currentTimestamp % 60;
        const timeLeft = 60 - currentSecondInCycle;
        let status = "OPEN";
        if (currentSecondInCycle >= 45 && currentSecondInCycle < 55) {
          status = "LOCKDOWN";
        } else if (currentSecondInCycle >= 55) {
          status = "RESULT";
        }
        const roundId = Math.floor(currentTimestamp / 60);

        return new Response(JSON.stringify({
          success: true,
          status,
          timeLeft,
          roundId: roundId.toString(),
          timestamp: currentTimestamp
        }), {
          status: 200,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
          }
        });
      }

      // Route: GET /api/users - Fetch all users from Cloudflare D1
      if (url.pathname === '/api/users' && method === 'GET') {
        // Secure it - only admins can pull user listings
        const isAdmin = await verifyAdmin(request, env);
        if (!isAdmin) {
          return new Response(JSON.stringify({ error: 'Unauthorized: Admin privileges required' }), {
            status: 403,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        const { results } = await env.DB.prepare(
          'SELECT id, name, email, role, balance, mobile, created_at FROM users ORDER BY created_at DESC'
        ).all();

        return new Response(JSON.stringify(results), {
          status: 200,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
          }
        });
      }

      // Route: POST /api/auth/google - Verify Google Sign-In ID Token, register/sync user, and return JWT Session
      if (url.pathname === '/api/auth/google' && method === 'POST') {
        try {
          const body: any = await request.json();
          const { id_token } = body;

          if (!id_token) {
            return new Response(JSON.stringify({ error: 'Missing parameter: id_token' }), {
              status: 400,
              headers: { 'Content-Type': 'application/json', ...corsHeaders }
            });
          }

          const payload = await verifyGoogleIdToken(id_token);
          const sub = payload.sub;
          const email = payload.email || `${sub}@sorat.live`;
          const name = payload.name || payload.given_name || 'Google Player';

          // Preserve existing role and balance if user already exists
          let existingUser: any = await env.DB.prepare(
            'SELECT role, balance FROM users WHERE id = ?'
          ).bind(sub).first();

          let finalRole = 'user';
          let finalBalance = 0;

          if (existingUser) {
            finalRole = existingUser.role || 'user';
            finalBalance = existingUser.balance || 0;
          } else {
            if (email.toLowerCase().trim() === 'nikhilrv8055@gmail.com') {
              finalRole = 'admin';
            }
          }

          // Securely upsert user in D1 database
          await env.DB.prepare(
            'INSERT INTO users (id, name, email, role, balance, mobile) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET name = excluded.name, email = excluded.email'
          )
          .bind(sub, name, email, finalRole, finalBalance, '')
          .run();

          // Generate secure edge session JWT
          const sessionPayload = {
            sub: sub,
            uid: sub,
            email: email,
            name: name,
            role: finalRole,
            iat: Math.floor(Date.now() / 1000),
            exp: Math.floor(Date.now() / 1000) + (30 * 24 * 60 * 60) // 30 days active
          };

          const jwtSecret = env.JWT_SECRET || 'sorat_live_jwt_super_secret_key_12345!';
          const customToken = await generateJWT(sessionPayload, jwtSecret);

          return new Response(JSON.stringify({
            success: true,
            token: customToken,
            user: {
              id: sub,
              uid: sub,
              name: name,
              email: email,
              role: finalRole,
              balance: finalBalance
            }
          }), {
            status: 200,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        } catch (err: any) {
          console.error('[Google Auth Error]:', err.message || err);
          return new Response(JSON.stringify({ error: `Authentication failed: ${err.message || err}` }), {
            status: 401,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }
      }

      // Route: POST /api/users - Create/Register a new user (Self-registration)
      if (url.pathname === '/api/users' && method === 'POST') {
        const body: any = await request.json();
        const { id, name, email, role, balance, mobile } = body;

        if (!id || !name || !email) {
          return new Response(JSON.stringify({ error: 'Missing required parameters: id, name, email' }), {
            status: 400,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        await env.DB.prepare(
          'INSERT INTO users (id, name, email, role, balance, mobile) VALUES (?, ?, ?, ?, ?, ?)'
        )
        .bind(id, name, email, role || 'user', balance || 0.00, mobile || '')
        .run();

        return new Response(JSON.stringify({ success: true, message: 'User created successfully inside D1 database!' }), {
          status: 201,
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // Route: POST /api/admin/update-balance - Admin balance modification (add, remove, set) synced with Appwrite and D1
      if (url.pathname === '/api/admin/update-balance' && method === 'POST') {
        // 1. Admin Role Verification: Validate active admin session token
        const isAdmin = await verifyAdmin(request, env);
        if (!isAdmin) {
          console.error('[Worker Auth] Unauthorized balance modification attempt');
          return new Response(JSON.stringify({ error: 'Unauthorized: Admin privileges required' }), {
            status: 403,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        // 2. Data parsing block
        let body: any;
        try {
          const bodyText = await request.text();
          body = JSON.parse(bodyText);
        } catch (parseErr: any) {
          console.error('[Worker Parser] Failed to parse request body as JSON:', parseErr.message);
          return new Response(JSON.stringify({ 
            error: 'Failed to parse JSON body from request',
            details: parseErr.message 
          }), {
            status: 400,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        // 3. Parameters validation (userId, amount, action)
        const { userId, amount, action } = body;
        if (userId === undefined || amount === undefined || action === undefined) {
          console.error('[Worker Validation] Missing required parameters:', { userId, amount, action });
          return new Response(JSON.stringify({ 
            error: 'Missing required parameters: userId, amount, and action must be defined.',
            received: { userId, amount, action }
          }), {
            status: 400,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        const numericAmount = parseFloat(amount);
        if (isNaN(numericAmount) || numericAmount < 0) {
          console.error('[Worker Validation] Invalid amount parameter:', amount);
          return new Response(JSON.stringify({ 
            error: 'Invalid parameter: amount must be a non-negative number.',
            receivedAmount: amount 
          }), {
            status: 400,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        if (action !== 'add' && action !== 'remove' && action !== 'set') {
          console.error('[Worker Validation] Invalid action parameter:', action);
          return new Response(JSON.stringify({ 
            error: 'Invalid parameter: action must be either "add", "remove", or "set".',
            receivedAction: action 
          }), {
            status: 400,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        // 4. Appwrite Database Execution and Error Logging
        const appwriteEndpoint = 'https://api.sorat.in/v1';
        const projectId = '6a4e644b001268fb3a25';
        const databaseId = 'main';
        const collectionId = 'users';

        // Prepare Appwrite headers
        const appwriteHeaders: Record<string, string> = {
          'Content-Type': 'application/json',
          'X-Appwrite-Project': projectId,
        };

        if (env.APPWRITE_API_KEY) {
          appwriteHeaders['X-Appwrite-Key'] = env.APPWRITE_API_KEY;
        } else {
          const authHeader = request.headers.get('Authorization');
          if (authHeader && authHeader.startsWith('Bearer ')) {
            appwriteHeaders['X-Appwrite-JWT'] = authHeader.substring(7);
          }
        }

        let currentBalance = 0;
        let getResponse: Response;

        // Fetch current document first
        try {
          console.log(`[Worker Appwrite] GET User Document: ${userId}`);
          getResponse = await fetch(
            `${appwriteEndpoint}/databases/${databaseId}/collections/${collectionId}/documents/${userId}`,
            {
              method: 'GET',
              headers: appwriteHeaders
            }
          );

          if (!getResponse.ok) {
            const errText = await getResponse.text();
            console.error(`[Worker Appwrite] GET User failed with status ${getResponse.status}:`, errText);
            return new Response(JSON.stringify({
              error: `Appwrite document retrieval failed with status ${getResponse.status}`,
              status: getResponse.status,
              details: errText
            }), {
              status: getResponse.status === 401 || getResponse.status === 404 ? getResponse.status : 500,
              headers: { 'Content-Type': 'application/json', ...corsHeaders }
            });
          }

          const userDoc: any = await getResponse.json();
          currentBalance = userDoc.balance !== undefined ? parseFloat(userDoc.balance) : 0;
        } catch (err: any) {
          console.error('[Worker Appwrite] GET Request Try-Catch exception:', err.message);
          return new Response(JSON.stringify({
            error: 'Exception occurred while fetching document from Appwrite',
            details: err.message
          }), {
            status: 500,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        // Calculate new balance
        let newBalance = currentBalance;
        if (action === 'add') {
          newBalance = currentBalance + numericAmount;
        } else if (action === 'remove') {
          newBalance = Math.max(0, currentBalance - numericAmount);
        } else if (action === 'set') {
          newBalance = numericAmount;
        }

        // Update document in Appwrite
        let updateResponse: Response;
        try {
          console.log(`[Worker Appwrite] PATCH User Document: ${userId} with balance: ${newBalance}`);
          updateResponse = await fetch(
            `${appwriteEndpoint}/databases/${databaseId}/collections/${collectionId}/documents/${userId}`,
            {
              method: 'PATCH',
              headers: appwriteHeaders,
              body: JSON.stringify({
                data: {
                  balance: newBalance
                }
              })
            }
          );

          if (!updateResponse.ok) {
            const errText = await updateResponse.text();
            console.error(`[Worker Appwrite] PATCH User failed with status ${updateResponse.status}:`, errText);
            return new Response(JSON.stringify({
              error: `Appwrite document update failed with status ${updateResponse.status}`,
              status: updateResponse.status,
              details: errText
            }), {
              status: updateResponse.status === 401 || updateResponse.status === 404 ? updateResponse.status : 500,
              headers: { 'Content-Type': 'application/json', ...corsHeaders }
            });
          }
        } catch (err: any) {
          console.error('[Worker Appwrite] PATCH Request Try-Catch exception:', err.message);
          return new Response(JSON.stringify({
            error: 'Exception occurred while updating document in Appwrite',
            details: err.message
          }), {
            status: 500,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        // 5. Synchronize with D1 database
        try {
          await env.DB.prepare('UPDATE users SET balance = ? WHERE id = ?')
            .bind(newBalance, userId)
            .run();
          console.log(`[Worker D1] Synchronized user ${userId} balance in D1 to ${newBalance}`);
        } catch (d1Err: any) {
          console.error('[Worker D1] Failed to sync user balance in D1 database:', d1Err.message);
        }

        return new Response(JSON.stringify({
          success: true,
          userId,
          previousBalance: currentBalance,
          newBalance,
          action,
          message: 'Balance successfully updated in both Appwrite and D1 databases!'
        }), {
          status: 200,
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // Route: PUT /api/users/:id - Update user's role or balance/coins in D1 database
      if (userMatch && method === 'PUT') {
        const userId = userMatch[1];

        // Secure it - only admins can perform edits
        const isAdmin = await verifyAdmin(request, env);
        if (!isAdmin) {
          return new Response(JSON.stringify({ error: 'Unauthorized: Admin privileges required' }), {
            status: 403,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        const body: any = await request.json();
        const { role, balance, balanceAdjustment } = body;

        if (role !== undefined) {
          // Promote / Demote Admin
          await env.DB.prepare('UPDATE users SET role = ? WHERE id = ?')
            .bind(role, userId)
            .run();
        }

        if (balance !== undefined) {
          // Explicitly set Balance/Coins
          await env.DB.prepare('UPDATE users SET balance = ? WHERE id = ?')
            .bind(balance, userId)
            .run();
        } else if (balanceAdjustment !== undefined) {
          // Add or Subtract Balance/Coins
          await env.DB.prepare('UPDATE users SET balance = balance + ? WHERE id = ?')
            .bind(balanceAdjustment, userId)
            .run();
        }

        return new Response(JSON.stringify({ success: true, message: 'User updated successfully in D1 database!' }), {
          status: 200,
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // Route: DELETE /api/users/:id - Delete a user and clean their records
      if (userMatch && method === 'DELETE') {
        const userId = userMatch[1];

        // Secure it - only admins can delete accounts
        const isAdmin = await verifyAdmin(request, env);
        if (!isAdmin) {
          return new Response(JSON.stringify({ error: 'Unauthorized: Admin privileges required' }), {
            status: 403,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        // Run deletion query
        await env.DB.prepare('DELETE FROM users WHERE id = ?')
          .bind(userId)
          .run();

        return new Response(JSON.stringify({ success: true, message: 'User deleted successfully from D1 database!' }), {
          status: 200,
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // Route: GET /api/payment-proofs - Fetch all payment proofs from Cloudflare D1
      if (url.pathname === '/api/payment-proofs' && method === 'GET') {
        const isAdmin = await verifyAdmin(request, env);
        if (!isAdmin) {
          return new Response(JSON.stringify({ error: 'Unauthorized: Admin privileges required' }), {
            status: 403,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        const { results } = await env.DB.prepare(
          'SELECT id, user_email, screenshot_url, amount, status, created_at FROM payment_proofs ORDER BY created_at DESC'
        ).all();

        return new Response(JSON.stringify(results), {
          status: 200,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
          }
        });
      }

      // Route: POST /api/payment-proofs - Submit a new payment proof to D1
      if (url.pathname === '/api/payment-proofs' && method === 'POST') {
        const body: any = await request.json();
        const { id, user_email, screenshot_url, amount } = body;

        if (!id || !user_email || !screenshot_url || !amount) {
          return new Response(JSON.stringify({ error: 'Missing required parameters: id, user_email, screenshot_url, amount' }), {
            status: 400,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        await env.DB.prepare(
          'INSERT INTO payment_proofs (id, user_email, screenshot_url, amount, status) VALUES (?, ?, ?, ?, ?)'
        )
        .bind(id, user_email, screenshot_url, parseFloat(amount), 'pending')
        .run();

        return new Response(JSON.stringify({ success: true, message: 'Payment proof submitted to D1!' }), {
          status: 201,
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // Route: PUT /api/payment-proofs/:id - Approve or reject a payment proof
      if (proofMatch && method === 'PUT') {
        const proofId = proofMatch[1];
        const isAdmin = await verifyAdmin(request, env);
        if (!isAdmin) {
          return new Response(JSON.stringify({ error: 'Unauthorized: Admin privileges required' }), {
            status: 403,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        const body: any = await request.json();
        const { status } = body; // 'approved' or 'rejected'

        if (status !== 'approved' && status !== 'rejected') {
          return new Response(JSON.stringify({ error: 'Invalid status. Must be approved or rejected.' }), {
            status: 400,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        // Fetch current proof info
        const proof: any = await env.DB.prepare('SELECT user_email, amount, status FROM payment_proofs WHERE id = ?')
          .bind(proofId)
          .first();

        if (!proof) {
          return new Response(JSON.stringify({ error: 'Payment proof not found' }), {
            status: 404,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        if (proof.status !== 'pending') {
          return new Response(JSON.stringify({ error: 'Payment proof is already processed' }), {
            status: 400,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
          });
        }

        // Update the status in payment_proofs table
        await env.DB.prepare('UPDATE payment_proofs SET status = ? WHERE id = ?')
          .bind(status, proofId)
          .run();

        // If approved, add balance/coins to the user in D1 database
        if (status === 'approved') {
          await env.DB.prepare('UPDATE users SET balance = balance + ? WHERE email = ?')
            .bind(proof.amount, proof.user_email)
            .run();
        }

        return new Response(JSON.stringify({ 
          success: true, 
          message: `Payment proof ${status} successfully. ${status === 'approved' ? 'Coins added to user account!' : ''}` 
        }), {
          status: 200,
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // Default Route / Page Not Found
      return new Response(JSON.stringify({ error: 'Route not found' }), {
        status: 404,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        }
      });

    } catch (err: any) {
      return new Response(JSON.stringify({ error: err.message || 'Internal Server Error' }), {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        }
      });
    }
  }
};
